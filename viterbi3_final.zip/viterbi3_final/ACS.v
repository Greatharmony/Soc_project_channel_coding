
module acs #(
    parameter PM_W = 8,
    parameter BM_W = 6,
    parameter SW   = 2
)
(
    input clk,
    input rst,
    input acs_en,

    input pm_init,
    input commit_en,

    input [SW-1:0] ns,
    input [SW-1:0] prev_s0,
    input [SW-1:0] prev_s1,

    input [BM_W-1:0] bm_b0,
    input [BM_W-1:0] bm_b1,

    output reg [PM_W-1:0] surv_pm,
    output reg [SW-1:0] surv_state,
    output reg surv_sel,
    output reg acs_valid,

    output reg [SW-1:0] best_state,
    output reg [PM_W-1:0] best_pm
);

localparam [PM_W-1:0] INF = {PM_W{1'b1}};

// Previous Path Metrics
reg [PM_W-1:0] pm0, pm1, pm2, pm3;

// New Path Metrics
reg [PM_W-1:0] npm0, npm1, npm2, npm3;

// ACS calculation registers
reg [PM_W-1:0] prev_pm0_sel;
reg [PM_W-1:0] prev_pm1_sel;

reg [PM_W-1:0] cand0_pm;
reg [PM_W-1:0] cand1_pm;

reg [PM_W-1:0] win_pm;
reg [SW-1:0]   win_state;
reg            win_sel;


// ========================================
// 1. Previous PM Selection
// ========================================

always @(*) begin

    case (prev_s0)
        2'd0: prev_pm0_sel = pm0;
        2'd1: prev_pm0_sel = pm1;
        2'd2: prev_pm0_sel = pm2;
        default: prev_pm0_sel = pm3;
    endcase

    case (prev_s1)
        2'd0: prev_pm1_sel = pm0;
        2'd1: prev_pm1_sel = pm1;
        2'd2: prev_pm1_sel = pm2;
        default: prev_pm1_sel = pm3;
    endcase

end


// ========================================
// 2. Candidate Path Metric Calculation
// ========================================

always @(*) begin

    if (prev_pm0_sel == INF)
        cand0_pm = INF;
    else
        cand0_pm = prev_pm0_sel
                 + {{(PM_W-BM_W){1'b0}}, bm_b0};

    if (prev_pm1_sel == INF)
        cand1_pm = INF;
    else
        cand1_pm = prev_pm1_sel
                 + {{(PM_W-BM_W){1'b0}}, bm_b1};

end


// ========================================
// 3. ACS Compare and Select
// ========================================

always @(*) begin

    if (cand0_pm <= cand1_pm) begin

        win_pm    = cand0_pm;
        win_state = prev_s0;
        win_sel   = 1'b0;

    end
    else begin

        win_pm    = cand1_pm;
        win_state = prev_s1;
        win_sel   = 1'b1;

    end

end


// ========================================
// 4. Best State Selection
// ========================================

always @(*) begin

    best_pm    = INF;
    best_state = 0;

    if (pm0 < best_pm) begin
        best_pm    = pm0;
        best_state = 0;
    end

    if (pm1 < best_pm) begin
        best_pm    = pm1;
        best_state = 1;
    end

    if (pm2 < best_pm) begin
        best_pm    = pm2;
        best_state = 2;
    end

    if (pm3 < best_pm) begin
        best_pm    = pm3;
        best_state = 3;
    end

end


// ========================================
// 5. Sequential Logic
// ========================================

always @(posedge clk or negedge rst) begin

    if (!rst) begin

        pm0 <= 0;
        pm1 <= INF;
        pm2 <= INF;
        pm3 <= INF;

        npm0 <= INF;
        npm1 <= INF;
        npm2 <= INF;
        npm3 <= INF;

        surv_pm    <= 0;
        surv_state <= 0;
        surv_sel   <= 0;
        acs_valid  <= 0;

    end

    // Decoder initialization
    else if (pm_init) begin

        pm0 <= 0;
        pm1 <= INF;
        pm2 <= INF;
        pm3 <= INF;

        npm0 <= INF;
        npm1 <= INF;
        npm2 <= INF;
        npm3 <= INF;

        surv_pm    <= 0;
        surv_state <= 0;
        surv_sel   <= 0;
        acs_valid  <= 0;

    end

    // ACS calculation
    else if (acs_en) begin

        surv_pm    <= win_pm;
        surv_state <= win_state;
        surv_sel   <= win_sel;
        acs_valid  <= 1'b1;

        case (ns)

            2'd0: npm0 <= win_pm;
            2'd1: npm1 <= win_pm;
            2'd2: npm2 <= win_pm;
            2'd3: npm3 <= win_pm;

        endcase

    end

    // Commit new Path Metrics
    else if (commit_en) begin

        pm0 <= npm0;
        pm1 <= npm1;
        pm2 <= npm2;
        pm3 <= npm3;

        acs_valid <= 1'b0;

    end

    else begin

        acs_valid <= 1'b0;

    end

end

endmodule
