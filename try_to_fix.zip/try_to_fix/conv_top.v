// conv_top (최종 연결본) - viterbi_bmu / viterbi_bm_sel / viterbi_path / viterbi_fsm 은 팀원 파일 그대로 사용
//  N17: 인코딩 / P17: 경로 계산 + Process / M17: 결과 (오류면 Error 먼저) / SW15: 오류 삽입
module conv_top (
    input        clk,
    input        reset,        // CPU_RESETN (C12), active-low
    input        btn_enc,      // N17 (BTNC)
    input        btn_proc,     // P17 (BTNL)
    input        btn_res,      // M17 (BTNR)
    input        err_sw,       // SW15 (V10)
    input  [2:0] din,          // SW2, SW1, SW0
    output [6:0] seg,
    output [7:0] digit
);
    localparam N = 3, K = 3, LLR_W = 5, BM_W = 6, PM_W = 8;
    localparam [2:0] G0 = 3'b111, G1 = 3'b101;
    localparam PAIR_W = $clog2(N + 1);

    // 버튼 → 1클럭 펄스
    wire pls_enc, pls_proc, pls_res;
    button BT0 (clk, reset, btn_enc,  pls_enc);
    button BT1 (clk, reset, btn_proc, pls_proc);
    button BT2 (clk, reset, btn_res,  pls_res);

    // 1) 인코더 (+ 오류 삽입)
    wire enc_d0, enc_d1;                       // 사용 안 함
    wire [2*N-1:0] out;
    conv_encoder #(N) U1 (clk, reset, din, pls_enc, err_sw, enc_d0, enc_d1, out);

    // 2) 디코더 FSM
    wire bm_valid, path_init, path_acs_en, commit_en, fin_en, bm_en, acs_en, dec_done;
    wire [K-2:0]      state_idx;
    wire [PAIR_W-1:0] pair;
    //    FRAME_BITS = 처리할 쌍 개수 = 입력 비트 수 N (6 아님!)
    viterbi_fsm #(.K(K), .FRAME_BITS(N)) FSM (clk, reset, pls_proc, bm_valid,
        path_init, path_acs_en, commit_en, fin_en, bm_en, acs_en, state_idx, pair, dec_done);

    // 3) pair번째 쌍 → LLR (0 → +8, 1 → -8), llr0 ↔ G0, llr1 ↔ G1
    wire signed [LLR_W-1:0] llr0 = out[2*pair+1] ? -5'sd8 : 5'sd8;
    wire signed [LLR_W-1:0] llr1 = out[2*pair]   ? -5'sd8 : 5'sd8;

    // 4) BMU, BM 선택
    wire [BM_W-1:0] bm00, bm01, bm10, bm11, bm_b0, bm_b1;
    wire [K-2:0] prev_s0, prev_s1;
    wire [1:0] cw0, cw1;
    wire dec_bit;
    viterbi_bmu #(LLR_W, BM_W) BM1 (clk, reset, bm_en, llr0, llr1, bm00, bm01, bm10, bm11, bm_valid);
    viterbi_bm_sel #(K, G0, G1, BM_W) BMS1 (state_idx, bm00, bm01, bm10, bm11,
        prev_s0, prev_s1, cw0, cw1, bm_b0, bm_b1, dec_bit);

    // 5) ACS
    wire [PM_W-1:0] surv_pm, best_pm;
    wire [K-2:0] surv_state, best_state;
    wire surv_sel, acs_valid;
    acs #(PM_W, BM_W, K-1) ACS1 (clk, reset, acs_en, path_init, commit_en, state_idx, prev_s0, prev_s1,
        bm_b0, bm_b1, surv_pm, surv_state, surv_sel, acs_valid, best_state, best_pm);

    // 6) 경로 기록 (Register Exchange)
    //    acs_en 에는 FSM의 path_acs_en(PATH_UPDATE)을, decision 에는 ACS가 한 클럭 전에 저장한 surv_sel 을 연결
    wire [N-1:0] decoded;                      // decoded[0] = 첫 번째 비트 = din[0]
    viterbi_path #(.K(K), .FRAME_BITS(N)) PATH (
        .clk(clk), .reset(reset),
        .path_init(path_init), .acs_en(path_acs_en), .commit_en(commit_en), .fin_en(fin_en),
        .state_idx(state_idx), .decision(surv_sel), .prev_s0(prev_s0), .prev_s1(prev_s1),
        .dec_bit(dec_bit), .pair(pair), .best_state(best_state), .path_bits(decoded));

    // 7) 오류 판정 → 표시
    wire err_found = (best_pm != 0);
    conv_Display DP0 (clk, reset, pls_enc, pls_proc, pls_res, err_found, out, decoded, seg, digit);
endmodule
