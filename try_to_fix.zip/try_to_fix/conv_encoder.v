// conv_encoder (팀원 코드 기반 수정본)
//  - din[0]부터 부호화 (팀 규약, 디코더와 같은 순서)
//  - 매번 상태 00에서 시작 (temp 레지스터 제거)
//  - sel(N17 버튼 펄스)을 누른 순간의 din, err_sw로 코드워드 저장
//  - out[2k+1] = G0(111), out[2k] = G1(101) of din[k]
//  - err_sw = 1이면 out[3](din[1]의 G0)을 뒤집음 → 항상 정정 가능한 위치
module conv_encoder #(parameter N = 3)
(
    input  wire clk,
    input  wire reset,                // active-low
    input  wire [N-1:0] din,
    input  wire sel,                  // 인코딩 버튼 펄스 (N17)
    input  wire err_sw,               // 가장 왼쪽 스위치 (SW15)

    output reg  dout0,                // din[0]의 G0 (참고용, 디코더는 out 사용)
    output reg  dout1,                // din[0]의 G1 (참고용)
    output reg  [(2*N)-1:0] out
);

localparam ERR_POS = 3;

// K = 3, Memory = 2
reg [1:0] next_temp;                  // {전, 전전}
reg [(2*N)-1:0] next_out;

integer k;

// Combinational Logic
always @(*) begin
    next_temp = 2'b00;                // 프레임마다 상태 00에서 시작
    next_out  = {(2*N){1'b0}};

    for (k = 0; k < N; k = k + 1) begin
        // G1 = 1 + D + D^2 : 입 ^ 전 ^ 전전
        next_out[2*k+1] = din[k] ^ next_temp[1] ^ next_temp[0];
        // G2 = 1 + D^2     : 입 ^ 전전
        next_out[2*k]   = din[k] ^ next_temp[0];
        // 한 칸 밀기: 입 → 전, 전 → 전전
        next_temp = {din[k], next_temp[1]};
    end

    if (err_sw)
        next_out[ERR_POS] = ~next_out[ERR_POS];
end

// Sequential Logic
always @(posedge clk or negedge reset) begin
    if (!reset) begin
        out   <= {(2*N){1'b0}};
        dout0 <= 1'b0;
        dout1 <= 1'b0;
    end
    else if (sel) begin               // 버튼을 누른 순간에만 저장
        out   <= next_out;
        dout0 <= next_out[1];
        dout1 <= next_out[0];
    end
end

endmodule
