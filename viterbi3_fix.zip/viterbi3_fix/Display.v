module conv_Display (
    input            clk,
    input            rst,
    input            proc_pls,
    input            output_pls,
    input            sel,
    input      [5:0] out,
    input      [2:0] fin,
    output reg [6:0] seg,
    output reg [7:0] digit
);
    reg [13:0] count;
    reg        clk_10000;
    reg        show_proc;   // 1�̸� Process ǥ��
    reg        show_output; // 1�̸� fin(3��Ʈ) ǥ��, 0�̸� out(6��Ʈ) ǥ��

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            count     <= 14'd0;
            clk_10000 <= 1'b0;
        end else if (count == 14'd9999) begin
            count     <= 14'd0;
            clk_10000 <= ~clk_10000;
        end else begin
            count     <= count + 14'd1;
        end
    end

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            show_proc <= 1'b0;
        end else if (sel || output_pls) begin
            show_proc <= 1'b0; // sel�̳� output ������ Process ǥ�� ����
        end else if (proc_pls) begin
            show_proc <= ~show_proc;
        end
    end

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            show_output <= 1'b0;
        end else if (sel) begin
            show_output <= 1'b0; // sel ������ ���ڵ�(out) ���� ����
        end else if (output_pls) begin
            show_output <= ~show_output;
        end
    end

    always @(posedge clk_10000 or negedge rst) begin
        if (!rst) begin
            digit <= 8'b11111110;
        end else begin
            case (digit)
                8'b11111110: digit <= 8'b11111101;
                8'b11111101: digit <= 8'b11111011;
                8'b11111011: digit <= 8'b11110111;
                8'b11110111: digit <= 8'b11101111;
                8'b11101111: digit <= 8'b11011111;
                8'b11011111: digit <= 8'b10111111;
                8'b10111111: digit <= 8'b01111111;
                8'b01111111: digit <= 8'b11111110;
                default:     digit <= 8'b11111110;
            endcase
        end
    end

    reg       bit_val;
    reg       bit_en;
    reg [6:0] proc_seg;

    always @(*) begin
        bit_en  = 1'b1;
        bit_val = 1'b0;
        if (show_output) begin
            case (digit)
                8'b11111110: bit_val = fin[0];
                8'b11111101: bit_val = fin[1];
                8'b11111011: bit_val = fin[2];
                default:     bit_en  = 1'b0;
            endcase
        end else begin
            case (digit)
                8'b11111110: bit_val = out[0];
                8'b11111101: bit_val = out[1];
                8'b11111011: bit_val = out[2];
                8'b11110111: bit_val = out[3];
                8'b11101111: bit_val = out[4];
                8'b11011111: bit_val = out[5];
                default:     bit_en  = 1'b0;
            endcase
        end
    end

    always @(*) begin
        case (digit)
            8'b10111111: proc_seg = 7'b0011000; // P
            8'b11011111: proc_seg = 7'b1111010; // r
            8'b11101111: proc_seg = 7'b1100010; // o
            8'b11110111: proc_seg = 7'b0110001; // c
            8'b11111011: proc_seg = 7'b0110000; // e
            8'b11111101: proc_seg = 7'b0100100; // s
            8'b11111110: proc_seg = 7'b0100100; // s
            default:     proc_seg = 7'b1111111; // OFF
        endcase
    end

    always @(*) begin
        if (show_proc) begin
            seg = proc_seg;
        end else if (!bit_en) begin
            seg = 7'b1111111; // OFF
        end else if (bit_val == 1'b1) begin
            seg = 7'b1001111; // 1
        end else begin
            seg = 7'b0000001; // 0
        end
    end
endmodule