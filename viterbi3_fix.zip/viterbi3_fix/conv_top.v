module conv_top (
    input        clk,
    input        reset,
    input        sel,
    input        bm_btn,
    input        out_btn,
    input        err_sw,
    input  [2:0] din,
    output [6:0] seg,
    output [7:0] digit
);

    wire pls_sel, pls_bm, pls_path;
    wire dout0, dout1;
    wire [5:0] out;
    wire bm_en;

    localparam N             = 3;
    localparam FRAME_BITS    = 3;
    localparam LLR_W         = 5;
    localparam BM_W          = 6;
    localparam PM_W          = 8;
    localparam SW            = 2;
    localparam K             = 3;
    localparam PAIR_W        = $clog2(FRAME_BITS + 1);
    localparam [2:0] G0      = 3'b111;
    localparam [2:0] G1      = 3'b101;

    wire signed [LLR_W-1:0] llr0;
    wire signed [LLR_W-1:0] llr1;
    wire                    bm_valid;
    wire [BM_W-1:0]         bm00, bm01, bm10, bm11;

    wire [K-2:0]    ns; // �մ�/�׽�Ʈ��ġ���� ������ ���� ���� ��ȣ
    wire [K-2:0]    prev_s0, prev_s1;
    wire [1:0]      cw0, cw1;
    wire [BM_W-1:0] bm_b0, bm_b1;
    wire            dec_bit;

    wire              path_init, path_acs_en, commit_en, fin_en, acs_en, done;
    wire [K-2:0]      state_idx;
    wire [PAIR_W-1:0] pair;

    wire [PM_W-1:0] surv_pm;
    wire [SW-1:0]   surv_state;
    wire            surv_sel, acs_valid;
    wire [SW-1:0]   best_state;
    wire [PM_W-1:0] best_pm;

    wire [FRAME_BITS-1:0] path_bits;

    wire sym0 = (pair == 3'd0) ? out[5] :
                (pair == 3'd1) ? out[3] :
                (pair == 3'd2) ? out[1] : 1'b0;

    wire sym1 = (pair == 3'd0) ? out[4] :
                (pair == 3'd1) ? out[2] :
                (pair == 3'd2) ? out[0] : 1'b0;

    assign llr0 = sym1 ? -5'sd8 : 5'sd8;
    assign llr1 = sym0 ? -5'sd8 : 5'sd8;

    button BT0 (clk, reset, sel,     pls_sel);
    button BT1 (clk, reset, bm_btn,  pls_bm);
    button BT2 (clk, reset, out_btn, pls_path);

    conv_encoder #(N) U1 (
        clk, reset, din, pls_sel, err_sw, dout0, dout1, out
    );

    viterbi_bmu #(LLR_W, BM_W) BM1 (
        clk, reset, bm_en, llr0, llr1, bm00, bm01, bm10, bm11, bm_valid
    );

    viterbi_bm_sel #(K, G0, G1, BM_W) BMS1 (
        ns, bm00, bm01, bm10, bm11, prev_s0, prev_s1, cw0, cw1, bm_b0, bm_b1, dec_bit
    );

    viterbi_fsm #(K, FRAME_BITS, PAIR_W) FSM1 (
        clk, reset, pls_bm, bm_valid, path_init, path_acs_en,
        commit_en, fin_en, bm_en, acs_en, state_idx, pair, done
    );

    acs #(PM_W, BM_W, SW) ACS1 (
        clk, reset, acs_en, path_init, commit_en, ns, prev_s0, prev_s1, bm_b0, bm_b1,
        surv_pm, surv_state, surv_sel, acs_valid, best_state, best_pm
    );

    viterbi_path #(K, FRAME_BITS, PAIR_W) PATH1 (
        clk, reset, path_init, path_acs_en, state_idx, pair, commit_en, fin_en,
        prev_s0, prev_s1, dec_bit, surv_sel, best_state, path_bits
    );
wire [2:0] dec_bits;

wire [2:0] dec_bits;
    //assign dec_bits = path_bits[2:0];
    assign dec_bits = {path_bits[0], path_bits[1], path_bits[2]};

    conv_Display DP0 (
        clk, reset, pls_bm, pls_path, pls_sel, out, dec_bits, seg, digit
    );
    assign ns = state_idx;

endmodule